<div class="alert alert-dismissible alert-warning">
  <h4 class="alert-heading">Erreur</h4>
  <p class="mb-0">Erreur 404 : La page demandée est introuvable !</p>
</div>
